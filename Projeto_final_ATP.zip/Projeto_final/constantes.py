ESPECIALIDADES=["Cardiologia", "Pneumologia", "Ortopedia", "Medicina Familiar", "Pediatria"] #Pediatria sempre em ultimo
PULSEIRA=["Verde", "Amarela", "Vermelha"]