import FreeSimpleGUI as sg
import analisa_simulação as an
import grafico as g
import estatisticas as est
import clinica_alunos_oficial1 as ca

sg.theme("LightBlue")

# ---------------- FUNÇÕES ----------------

def janela_inicial():
    """Janela inicial de boas-vindas"""
    layout = [
        [sg.Image(filename="Projeto_final\clinica_logo_1.png", size=(1120, 600))],
        [sg.Text("Bem-vindo!", font=("Times New Roman", 35), justification="center", expand_x=True,background_color="white"),],
        [sg.Button("Entrar", size=(35, 2), font=("Times New Roman", 20), pad=(30,15), key="-Entrar-",button_color="#4A92AB"),
         sg.Button("Sair", size=(35, 2), font=("Times New Roman", 20), pad=(30,15), key="-Sair-",button_color="#4A92AB")]
    ]
    return sg.Window("Bem-vindo", layout, size=(1200, 820), element_justification="c",background_color="white")

def center_window(width, height):
    screen_w, screen_h = sg.Window.get_screen_size()
    x = (screen_w - width) // 2
    y = (screen_h - height) // 2
    return x, y

def janela_graficos(simulacao):
    """Janela modal de gráficos"""
    layout = [
        [sg.Text("Gráficos", font=("Times New Roman", 20), justification="center", expand_x=True)],
        [sg.Button("Tempo de espera médio por especialidade", size=(40,2), key="-G_ESP-",button_color="#4A92AB")],
        [sg.Button("Distribuição do tempo de permanência", size=(40,2), key="-G_DISTRIB-",button_color="#4A92AB")],
        [sg.Button("Nº de doentes por especialidade", size=(40,2), key="-G_DOENTES-",button_color="#4A92AB")],
        [sg.Button("Atendimento imediato vs em espera", size=(40,2), key="-G_ATEND-",button_color="#4A92AB")],
        [sg.Button("Atendimento imediato por especialidade", size=(40,2), key="-G_ATEND_ESP-",button_color="#4A92AB")],
        [sg.Button("Afluência", size=(40,2), key="-G_AFL-",button_color="#4A92AB")],
        [sg.Button("Pulseiras por especialidade", size=(40,2), key="-G_PUL_ESP-",button_color="#4A92AB")],
        [sg.Button("Tempo médio de espera por pulseira", size=(40,2), key="-G_TEMP_MED_PUL-",button_color="#4A92AB")],
        [sg.Button("Distribuição do sexo dos doentes", size=(40,2), key="-G_DISTRIB_SEX-",button_color="#4A92AB")],
        [sg.Button("Distribuição etária dos doentes", size=(40,2), key="-G_DISTRIB_IDADE-",button_color="#4A92AB")],
        [sg.Button("Evolução das filas de espera por especialidade", size=(40,2), key="-G_EVOL_FILA-",button_color="#4A92AB")],
        [sg.Button("Voltar", size=(20,2),button_color="#4A92AB")]
    ]
    window = sg.Window("Gráficos",layout,modal=True,location=(320, 160),size=(350,600))

    stop = False
    while not stop:
        event, _ = window.read()
        if event in (sg.WINDOW_CLOSED, "Voltar"):
            stop = True

        elif simulacao is None:
            sg.popup("Carregue uma simulação primeiro!",button_color="#4A92AB")
            stop = True

        else:# Chamadas dos gráficos
            if event == "-G_ESP-":
                g.grafico_tempo_medio_espera_por_especialidade(simulacao[1])
            elif event == "-G_DISTRIB-":
                g.grafico_distribuicao_tempo_permanencia(simulacao[1])
            elif event == "-G_DOENTES-":
                g.grafico_doentes_por_especialidade(simulacao[1])
            elif event == "-G_ATEND-":
                g.atendimento_imediato_vs_em_espera(simulacao[1])
            elif event == "-G_ATEND_ESP-":
                g.atendimento_imediato_por_especialidade(simulacao[1])
            elif event == "-G_AFL-":
                g.graph_afluencia(simulacao[0]["TEMPO_SIMULACAO"],simulacao[7],10)
            elif event == "-G_PUL_ESP-":
                g.pulseiras_especialidade(g.pacientes_especialidade(simulacao[1]))
            elif event == "-G_TEMP_MED_PUL-":
                g.graph_tempo_pul(g.paciente_pulseira(simulacao[1]))
            elif event == "-G_DISTRIB_SEX-":
                g.grafico_distribuicao_sexo(simulacao[1])
            elif event == "-G_DISTRIB_IDADE-":
                g.grafico_distribuicao_idades(simulacao[1])
            elif event == "-G_EVOL_FILA-":
                g.grafico_filas(simulacao[6],10)

    window.close()

def popup_estatistica(titulo, texto):
    layout = [
        [sg.Multiline(
            texto,
            size=(1200, 820),
            disabled=True,
            font=("Times New Roman", 12)
        )],
        [sg.Button("Fechar")]
    ]
    window = sg.Window(titulo, layout, modal=True)
    window.read()
    window.close()

def janela_estatisticas(simulacao):
    """Janela modal de estatísticas"""
    layout = [
    [
        sg.Column([
            [sg.Text("Estatísticas", font=("Times New Roman", 25), justification="center", expand_x=True)],
            [sg.Button("Maior tempo de espera", size=(40,2), key="-E_MAIOR_TE-",button_color="#4A92AB")],
            [sg.Button("Maior tempo de permanência", size=(40,2), key="-E_MAIOR_TP-",button_color="#4A92AB")],
            [sg.Button("Nº de pessoas suspeitas", size=(40,2), key="-E_SUS-",button_color="#4A92AB")],
            [sg.Button("Analisa doente com maior tempo de espera", size=(40,2), key="-E_ANALISA-",button_color="#4A92AB")],
            [sg.Button("Especialidades sob pressão", size=(40,2), key="-E_ESP_PRES-",button_color="#4A92AB")],
            [sg.Button("Percentagem de ocupação dos médicos", size=(40,2), key="-E_PERC-",button_color="#4A92AB")],
            [sg.Button("Tempos médios por pulseira e análise da prioridade", size=(40,2), key="-E_TEMP_MED_PUL_AND_ANALISE-",button_color="#4A92AB")],
            [sg.Button("Percentagem de inversão da prioridade", size=(40,2), key="-E_PERC_INVERT-",button_color="#4A92AB")],
            [sg.Button("Deteção de períodos críticos", size=(40,2), key="-E_CRITIC-",button_color="#4A92AB")],
            [sg.Button("Voltar", size=(20,2),button_color="#4A92AB")]
        ]),
        sg.VSeparator(),# separar a janela 
        sg.Column([
            [sg.Text("Resultado", font=("Times New Roman", 18))],
            [sg.Multiline("",size=(60, 28),key="-RESULTADO-",disabled=True,autoscroll=True,background_color="white")]
        ])
    ]
]
    window =sg.Window("Estatísticas", layout, modal=True)

    stop = False
    while not stop:
        event, _ = window.read()
        if event in (sg.WINDOW_CLOSED, "Voltar"):
            stop = True

        elif simulacao is None:
            sg.popup("Carregue uma simulação primeiro!")
            stop = True

        else:
            # Chamadas das estatísticas
            if event == "-E_MAIOR_TE-":
                resultado = est.maior_tempo_espera(simulacao[1])
                texto=f"{resultado[0]}com {resultado[1]} na {resultado[2]} apresenta o maior tempo de espera de {resultado[3]} minutos"
                window["-RESULTADO-"].update(str(texto))
            elif event == "-E_MAIOR_TP-":
                resultado = est.maior_tempo_permanencia(simulacao[1])
                texto=f"{resultado[0]}com {resultado[1]} na {resultado[2]} apresenta o maior tempo de permanência de {resultado[3]} minutos"
                window["-RESULTADO-"].update(str(texto))
            elif event == "-E_SUS-":
                resultado = est.num_pessoas_suspeitas(simulacao[1])
                window["-RESULTADO-"].update(str(resultado))
            elif event == "-E_ANALISA-":
                pessoa = est.maior_tempo_espera(simulacao[1])
                resultado = est.analisa_doente(simulacao[1],pessoa[1], simulacao[0]["TEMPO_SIMULACAO"])
                texto=""
                for r in resultado:
                    texto+=f"O doente {r[0]["doente"]} da especialidade {r[0]["especialidade"]} tem as seguintes informações:"+"\n"
                    texto+=f"Id:{r[0]["id"]}"+"\n"+f"Sexo:{r[0]["sexo"]}"+"\n"+f"Idade:{r[0]["idade"]}"+"\n"+f"Pulseira:{r[0]["pulseira"]}"+"\n"+f"Tempo de espera:{r[0]["tempo_espera"]}"+"\n"+f"Tempo de permanência: {r[0]["tempo_permanencia"]}"+"\n"+f"Tempo de início da consulta:{r[0]["tempo_inicio_consulta"]}"+"\n" #tentar meter um input
                    texto+="Conclusões:"+"\n"+f"{r[1]}"

                window["-RESULTADO-"].update(texto)
            elif event == "-E_ESP_PRES-":
                resultado = est.especialidades_sob_pressao(simulacao[1],simulacao[3],simulacao[0]["TEMPO_SIMULACAO"],90,0.8)
                window["-RESULTADO-"].update(str(resultado))
            elif event == "-E_PERC-":
                resultado = est.ocupaçao_medico_perc(simulacao[3],simulacao[0]["TEMPO_SIMULACAO"])
                texto=""
                for r in resultado:
                    texto+=r+"\n"
                window["-RESULTADO-"].update(texto) # window["-RESULTADO-"].update(str(resultado))
            elif event == "-E_TEMP_MED_PUL_AND_ANALISE-":
                resultado = est.tempo_medio_por_pulseira(simulacao[1])
                window["-RESULTADO-"].update(str(resultado))
            elif event == "-E_PERC_INVERT-":
                resultado = est.percentagem_inversao_prioridade(simulacao[1])
                window["-RESULTADO-"].update(str(resultado))
            elif event == "-E_CRITIC-":
                resultado = est.deteta_periodos_criticos(simulacao[1], simulacao[0]["TEMPO_SIMULACAO"], 90, 60)
                window["-RESULTADO-"].update(str(resultado))
    
    window.close()


def janela_principal():
    """Janela principal da simulação"""
    coluna_botoes = [
        [sg.Button("Executar nova simulação", size=(35,2), font=("Times New Roman", 25), key="-EXEC-",p=(10,12),button_color="#4A92AB")],
        [sg.Button("Carregar simulação", size=(35,2), font=("Times New Roman", 25), key="-CARR-",p=(10,12),button_color="#4A92AB")],
        [sg.Button("Estatísticas", size=(35,2), font=("Times New Roman", 25), key="-STATS-",p=(10,12),button_color="#4A92AB")],
        [sg.Button("Gráficos", size=(35,2), font=("Times New Roman", 25), key="-GRAF-",p=(10,12),button_color="#4A92AB")],
        [sg.Button("Visualização", size=(35,2), font=("Times New Roman", 25), key="-VISUALIZAÇÃO-",p=(10,12),button_color="#4A92AB")],
        [sg.Button("Sair", size=(35,2), font=("Times New Roman", 25), key="-SAIR-",p=(10,12),button_color="#4A92AB")]
    ]

    coluna_imagem = [[sg.Image(filename="Projeto_final\image_medicos.png", size=(600, 800),p=(0,12))]]

    layout = [
        [sg.Text("Simulação Clínica Hospitalar", font=("Times New Roman", 25), justification="center", expand_x=True)],
        [sg.HorizontalSeparator()],
        [sg.Column(coluna_botoes, vertical_alignment="top"),
         sg.VerticalSeparator(),
         sg.Column(coluna_imagem, vertical_alignment="top")]
    ]

    

    window_width, window_height = 1200, 820
    screen_width, screen_height = sg.Window.get_screen_size()
    x = (screen_width - window_width) // 2
    y = (screen_height - window_height) // 2

    return sg.Window(
        "Interface",
        layout,
        size=(window_width, window_height),
        location=(x, y),  # usa coordenadas calculadas
        resizable=False
    )
    




def janela_visualizacao(historico_filas):
    # Descobrir especialidades
    especialidades = sorted(set(e[1] for e in historico_filas))

    layout = [
        [sg.Text("Visualização Dinâmica da Fila", font=("Times New Roman", 25))],
        [sg.Text("Escolha Especialidade:"), sg.Combo(especialidades, key="-ESP-", readonly=True)],
        [sg.Button("Iniciar",key="-Init-",button_color="#4A92AB"), sg.Button("Voltar",key="-VOLT-",button_color="#4A92AB")],
        [sg.Graph(
            canvas_size=(900, 400),
            graph_bottom_left=(0, 0),
            graph_top_right=(900, 400),
            background_color="white",
            key="-GRAPH-"
        )]
    ]

    window = sg.Window("Visualização Dinâmica", layout, modal=True)
    graph = window["-GRAPH-"]

    stop = False
    iniciar = False
    indice = 0
    esp_selecionada = None

    # Contadores das filas
    fila_vermelha = 0
    fila_amarela = 0
    fila_verde = 0

    while not stop:
        event, values = window.read(timeout=200)

        if event in (sg.WINDOW_CLOSED, "-VOLT-"):
            stop = True
            
        if event == "-Init-":
            esp_selecionada = values["-ESP-"]
            if not esp_selecionada:
                sg.popup("Escolha uma especialidade antes de iniciar!")
            else:
                # Filtrar histórico da especialidade
                eventos_filtrados = [e for e in historico_filas if e[1] == esp_selecionada]
                indice = 0
                iniciar = True
                # Reset filas
                fila_vermelha = 0
                fila_amarela = 0
                fila_verde = 0
                graph.erase()

        if iniciar and indice < len(eventos_filtrados):
            evento = eventos_filtrados[indice]
            tempo, especialidade, tamanho, cor, tipo_evento = evento  # agora temos o tipo_evento

            # Atualiza a fila baseada no tipo de evento
            if tipo_evento == "chegada":
                if cor == "Vermelha":
                    fila_vermelha += 1
                elif cor == "Amarela":
                    fila_amarela += 1
                elif cor == "Verde":
                    fila_verde += 1
            elif tipo_evento == "saída":
                if cor == "Vermelha" and fila_vermelha > 0:
                    fila_vermelha -= 1
                elif cor == "Amarela" and fila_amarela > 0:
                    fila_amarela -= 1
                elif cor == "Verde" and fila_verde > 0:
                    fila_verde -= 1

            # Limpa e redesenha o gráfico
            graph.erase()
            cores_map = {"Vermelha": "#FF4C4C", "Amarela": "#FFD93D", "Verde": "#6BCF63"}
            pos_y = {"Vermelha": 300, "Amarela": 200, "Verde": 100}
            filas = {"Vermelha": fila_vermelha, "Amarela": fila_amarela, "Verde": fila_verde}

            for cor_nome in ["Vermelha", "Amarela", "Verde"]:
                x = 50
                y = pos_y[cor_nome]
                for _ in range(filas[cor_nome]):
                    graph.draw_rectangle((x, y), (x + 20, y + 20), fill_color=cores_map[cor_nome], line_color="black")
                    x += 25
                graph.draw_text(f"Nº: {filas[cor_nome]}", (850, y + 10), font=("Times New Roman", 12))

            graph.draw_text(f"Tempo: {tempo:.2f}", (450, 350), font=("Times New Roman", 14))
            indice += 1
    window.close()


def janela_loading():
    layout = [
        [sg.Text("A executar simulação...", font=("Times New Roman", 18), justification="center", expand_x=True)],
        [sg.Text("Por favor aguarde.", justification="center", expand_x=True)],
        [sg.ProgressBar(100, orientation="h", size=(30, 20), key="-PB-")]
    ]

    return sg.Window(
        "Aguarde",
        layout,
        modal=True,
        finalize=True,
        element_justification="center"
    )


def janela_executar_simulacao():

    # -------- PASSO 1: parâmetros --------
    parametros = janela_parametros_simulacao()
    if parametros is None:
        return  # utilizador cancelou

    # -------- PASSO 2: loading --------
    loading = janela_loading()
    loading.read(timeout=100)
    loading["-PB-"].update(30)

    (
        doentes_atendidos_info,
        chegadas,
        historico_filas,
        medicos,
        filas_espera,
        historico_ocupacao,
        parametros_usados
    ) = ca.simula(parametros)

    loading["-PB-"].update(100)
    loading.close()

    # -------- PASSO 3: guardar / voltar --------
    layout = [
        [sg.Text("Simulação executada com sucesso!",
                 font=("Times New Roman", 20),
                 justification="center",
                 expand_x=True)],

        [sg.Button("Guardar simulação", size=(30,2), button_color="#4A92AB"),
         sg.Button("Voltar", size=(30,2), button_color="#4A92AB")]
    ]

    window = sg.Window("Resultado", layout, modal=True)

    stop = False
    while not stop:
        event, _ = window.read()

        if event in (sg.WINDOW_CLOSED, "Voltar"):
            stop = True

        elif event == "Guardar simulação":
            nome = sg.popup_get_file(
                "Guardar simulação",
                save_as=True,
                file_types=(("Ficheiros JSON", "*.json"),),
                default_extension=".json"
            )

            if nome:
                ca.guarda_simulacao(
                    doentes_atendidos_info,
                    chegadas,
                    historico_filas,
                    medicos,
                    filas_espera,
                    historico_ocupacao,
                    parametros,
                    nome
                )
                sg.popup("Simulação guardada com sucesso!",
                         button_color="#4A92AB")

            stop = True

    window.close()

def valida_parametros(values):

    if not values["-TEMPO_SIM-"].isdigit():
        sg.popup("Tempo de simulação inválido.")
        return None

    if not values["-TMC-"].isdigit():
        sg.popup("Tempo médio de consulta inválido.")
        return None

    # Número de médicos
    if values["-MEDICOS-"].lower() != "aleatório":
        if not values["-MEDICOS-"].isdigit():
            sg.popup("Número de médicos inválido.")
            return None
        if int(values["-MEDICOS-"]) < 5:
            sg.popup("Deve colocar um número maior ou igual que 5 para garantir pelo menos um médico por especialidade.")
            return None

    # Taxa de chegada
    taxa_txt = values["-TAXA-"]
    if "/" in taxa_txt:
        partes = taxa_txt.split("/")
        if len(partes) != 2 or not partes[0].isdigit() or not partes[1].isdigit():
            sg.popup("Taxa de chegada inválida.")
            return None
        taxa_chegada = int(partes[0]) / int(partes[1])
    else:
        try:
            taxa_chegada = float(taxa_txt)
        except ValueError:
            sg.popup("Taxa de chegada inválida.")
            return None

    return {
        "TEMPO_SIMULACAO": int(values["-TEMPO_SIM-"]),
        "NUM_MEDICOS": None if values["-MEDICOS-"].lower() == "aleatório" else int(values["-MEDICOS-"]),
        "TAXA_CHEGADA": taxa_chegada,
        "TEMPO_MEDIO_CONSULTA": int(values["-TMC-"]),
        "DISTRIBUICAO_TEMPO_CONSULTA": values["-DIST-"]
    }


def janela_parametros_simulacao():

    layout = [
        [sg.Text("Parâmetros da Simulação", font=("Times New Roman", 22))],

        [sg.Text("Tempo de simulação (min):"),
         sg.Input("480", key="-TEMPO_SIM-")],

        [sg.Text("Número de médicos:"),
         sg.Input("aleatório", key="-MEDICOS-"),
         sg.Text("(ex: 5 ou aleatório)")],

        [sg.Text("Taxa de chegada (doentes/min):"),
         sg.Input("15/60", key="-TAXA-"),
         sg.Text("(ex: 15/60)")],

        [sg.Text("Tempo médio de consulta (min):"),
         sg.Input("15", key="-TMC-")],

        [sg.Text("Distribuição do tempo de consulta:"),
         sg.Combo(
             ["exponential", "normal", "uniform"],
             default_value="exponential",
             readonly=True,
             key="-DIST-"
         )],

        [sg.HorizontalSeparator()],

        [sg.Button("Executar simulação", button_color="#4A92AB"),
         sg.Button("Cancelar", button_color="#4A92AB")]
    ]

    window = sg.Window("Configurar Simulação", layout, modal=True)

    parametros = None

    while parametros is None:
        event, values = window.read()

        if event in (sg.WINDOW_CLOSED, "Cancelar"):
            window.close()
            return None

        if event == "Executar simulação":
            parametros = valida_parametros(values)

    window.close()
    return parametros



# ---------------- LOOP PRINCIPAL ----------------

def main():
    # 1. Janela inicial
    window = janela_inicial()
    entrar = False
    stop = False

    while not stop:
        event, values = window.read()
        if event in (sg.WINDOW_CLOSED, "-Sair-"):
            stop = True
            entrar = False
        elif event == "-Entrar-":
            stop = True
            entrar = True
    window.close()

    simulacao_carregada = None
    
    if entrar:
        window = janela_principal()
    
        stop1=False
        while not stop1:
            event, values = window.read()
            if event in (sg.WINDOW_CLOSED, "-SAIR-"):
                stop1 = True
                entrar = False

            elif event == "-CARR-":
                filename = sg.popup_get_file("Escolha uma simulação",background_color="white",button_color="#4A92AB", file_types=(("Ficheiros JSON", "*.json"),))
                if filename:
                    simulacao_carregada = an.carrega_simulacao(filename)
                    sg.popup("Simulação carregada com sucesso!",button_color="#4A92AB")

            elif event == "-GRAF-":
                if simulacao_carregada is None:
                    sg.popup("Carregue uma simulação primeiro!",button_color="#4A92AB")
                else:
                    window.hide()
                    janela_graficos(simulacao_carregada)
                    window.un_hide()

            elif event == "-STATS-":
                if simulacao_carregada is None:
                    sg.popup("Carregue uma simulação primeiro!",button_color="#4A92AB")
                else:
                    window.hide()
                    janela_estatisticas(simulacao_carregada)
                    window.un_hide()
            elif event == "-VISUALIZAÇÃO-":
                if simulacao_carregada is None:
                    sg.popup("Carregue uma simulação primeiro!",button_color="#4A92AB")
                else:
                    window.hide()  # fecha a janela principal
                    janela_visualizacao(simulacao_carregada[6])  # passa o histórico de filas
                    # após fechar a visualização, podes reabrir a janela principal
                    window.un_hide()
            elif event == "-EXEC-":
                window.hide()
                janela_executar_simulacao()
                window.un_hide()

if __name__ == "__main__":
    main()