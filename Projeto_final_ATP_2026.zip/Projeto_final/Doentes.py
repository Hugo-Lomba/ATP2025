import random
import constantes as cte
import json




def cria_doente(contagem):
    f = open("./Projeto_final/pessoas.json","r", encoding='utf-8')
    pes = json.load(f)   
    pessoa = random.choice(pes)
    paciente={
        "nome": pessoa.get("nome"),
        "id":f"d{contagem}",
        "sexo": pessoa.get("sexo"),
        "idade":pessoa.get("idade"),
        "especialidade": random.choice(cte.ESPECIALIDADES),
        "pulseira":random.choice(cte.PULSEIRA)
    }
    if paciente["idade"]>=18 and paciente["especialidade"]=="Pediatria":
        paciente["especialidade"]=random.choice(cte.ESPECIALIDADES[:-1])
    f.close()
    return paciente