## Análise de uma Simulação

Nesta secção, iremos analisar uma das simulações obtidas no âmbito do projeto. O objetivo é descrever, de forma sucinta, o processo de execução, carregamento e preparação da simulação, permitindo posteriormente a análise de estatísticas, gráficos e visualizações.

### Janela Inicial

Ao executar o código, surge uma janela inicial com uma mensagem de boas-vindas, o logótipo da clínica e duas opções disponíveis: **Entrar** e **Sair**.

![Janela inicial da aplicação](Imagens_suport_md/janela_inicial.png)

### Menu Principal

Ao selecionar a opção **Entrar**, é apresentado o menu principal da aplicação, contendo as seguintes funcionalidades:
- Executar Simulação  
- Carregar Simulação  
- Estatísticas  
- Gráficos  
- Visualização 
- Sair

![Menu principal](Imagens_suport_md/janela_principal.png)

### Execução de uma Nova Simulação

Ao tentar aceder às opções **Estatísticas**, **Gráficos** ou **Visualização** sem uma simulação ativa, surge uma janela *popup* a informar que é necessário **executar ou carregar uma simulação previamente**.  
Deste modo, foi escolhida a opção **Executar Simulação**.

Ao selecionar esta opção, é aberta uma janela de definição de parâmetros, onde foram configurados os seguintes valores:
- Tempo de simulação: **480 minutos**
- Número de médicos: **6**
- Taxa de chegada: **15 pacientes por hora**
- Tempo médio de consulta: **15 minutos**
- Distribuição do tempo de consulta: **Exponencial**

![Janela de parâmetros da simulação](Imagens_suport_md/parametros.png)


Após a definição dos parâmetros, foi selecionado o botão **Executar Simulação**.

### Execução e Armazenamento

Durante a execução, é apresentada uma janela de *loading*, indicando que a simulação está a ser processada.

![Janela de loading](Imagens_suport_md/loading.png)

Concluída a execução, surge uma mensagem a indicar que a **simulação foi executada com sucesso**, sendo possível escolher entre **Guardar** ou **Voltar**.

![Simulação carregada com sucesso](Imagens_suport_md/executada_sucesso.png)

Ao selecionar **Guardar**, é aberta uma janela *Save As*, permitindo guardar o ficheiro da simulação no dispositivo com o nome pretendido.

### Carregamento da Simulação

De volta ao menu principal, foi utilizada a opção **Carregar Simulação**, abrindo uma nova janela que permite selecionar o ficheiro previamente guardado através do botão **Browse**.

![Janela de carregamento da simulação](Imagens_suport_md/browse.png)

Após a seleção do ficheiro, é apresentada uma mensagem a confirmar que a **simulação foi carregada com sucesso**, regressando-se ao menu principal. A partir deste momento, torna-se possível analisar corretamente as **estatísticas**, **gráficos** e **visualizações** da simulação.


## Análise das Estatísticas da Simulação

Após o carregamento da simulação, foi possível aceder ao menu de **Estatísticas**, que disponibiliza várias análises relevantes para avaliar o desempenho da clínica, a pressão sobre os recursos e o cumprimento das prioridades. Seguidamente, apresenta-se a análise dos resultados obtidos para cada opção disponível.

![Menu de estatísticas](Imagens_suport_md/menu_est.png)

### Maior Tempo de Espera

O doente **Barack Pombicha** (ID: d65), da especialidade **Medicina Familiar**, apresentou o maior tempo de espera registado, com um valor de **343,49 minutos**.

![Resultado do maior tempo de espera](Imagens_suport_md/est1.png)

Este valor extremamente elevado indica uma situação de forte congestionamento nesta especialidade, afetando sobretudo doentes de menor prioridade.

---

### Maior Tempo de Permanência

O mesmo doente, **Barack Pombicha** (ID: d65), registou também o maior tempo total de permanência na clínica, com **371,81 minutos**.

![Resultado do maior tempo de permanência](Imagens_suport_md/est2.png)

A coincidência entre maior tempo de espera e maior tempo de permanência reforça a ideia de que o atraso no atendimento teve impacto direto na experiência global do doente.

---

### Número de Pessoas Suspeitas

Do total de **112 doentes**, foram identificados **13 doentes sob vigilância**, apresentando valores de tempo considerados suspeitos.

![Número de pessoas suspeitas](Imagens_suport_md/est3.png)

Este número sugere a existência de casos anómalos que podem estar associados a picos de procura, indisponibilidade de médicos ou situações excecionais na simulação.

---

### Análise do Doente com Maior Tempo de Espera

O doente **Barack Pombicha**, da especialidade **Medicina Familiar**, apresenta o seguinte perfil:
- ID: d65  
- Sexo: Masculino  
- Idade: 85  
- Pulseira: Verde  
- Tempo de espera: 343,49 minutos  
- Tempo de permanência: 371,81 minutos  
- Início da consulta: 599,31 minutos  

Conclusões principais:
- Permanência superior a 5 horas na clínica hospitalar  
- Esteve em lista de espera, não sendo atendido de imediato  
- A pulseira verde indica menor prioridade  
- A consulta iniciou-se após o fecho da clínica  

![Análise individual do doente](Imagens_suport_md/est4.png)

Esta análise evidencia que doentes de menor prioridade podem ser significativamente penalizados em contextos de elevada pressão.

---

### Especialidades Sob Pressão

Considerando um limite de tempo médio de espera de **90 minutos** e uma taxa de ocupação médica superior a **80%**, a especialidade identificada sob pressão foi:

- **Medicina Familiar**
  - Tempo médio de espera: **113,59 minutos**
  - Taxa de ocupação: **129,33%**

![Especialidades sob pressão](Imagens_suport_md/est5.png)

Este resultado confirma que a Medicina Familiar é o principal ponto crítico da simulação, apresentando simultaneamente elevada procura e sobrecarga dos médicos.

---

### Percentagem de Ocupação dos Médicos

A ocupação dos médicos ao longo do dia foi a seguinte:
- M1 (Cardiologia): 72,14%  
- M2 (Pneumologia): 111,63%  
- M3 (Ortopedia): 45,62%  
- M4 (Medicina Familiar): 129,33%  
- M5 (Pediatria): 2,89%  
- M6 (Ortopedia): 42,17%  

![Percentagem de ocupação dos médicos](Imagens_suport_md/est6.png)

Observa-se um forte desequilíbrio na distribuição da carga de trabalho, com alguns médicos sobrecarregados e outros com níveis muito baixos de ocupação.

---

### Tempos Médios por Pulseira

Os tempos médios de espera por prioridade foram:
- Vermelha: **18,42 minutos**
- Amarela: **18,71 minutos**
- Verde: **105,61 minutos**

![Tempos médios por pulseira](Imagens_suport_md/est7.png)

Os resultados demonstram que as prioridades mais elevadas são, em geral, respeitadas, enquanto os doentes com pulseira verde acumulam tempos de espera significativamente superiores.

---

### Percentagem de Inversão da Prioridade

Em **33,33%** das comparações analisadas, doentes com menor prioridade apresentaram tempos de espera inferiores aos de doentes prioritários.

![Percentagem de inversão de prioridade](Imagens_suport_md/est8.png)

Este fenómeno explica-se por fatores como:
- Chegadas espaçadas em determinadas especialidades  
- Indisponibilidade momentânea dos médicos noutras especialidades  
Assim, um doente verde pode ser atendido mais rapidamente do que um doente vermelho de outra especialidade sobrecarregada.

---

### Deteção de Períodos Críticos

Considerando intervalos de **1 hora** e um limite de espera de **90 minutos**, foram identificados vários períodos críticos, sobretudo nas especialidades de **Medicina Familiar** e **Pneumologia**, com especial incidência em doentes de pulseira verde e amarela.

![Deteção de períodos críticos](Imagens_suport_md/est9.png)

Estes períodos correspondem a fases do dia com elevada pressão sobre os recursos, resultando em tempos médios de espera bastante elevados.

---

### Análise Global das Estatísticas

De forma geral, os resultados evidenciam que a **Medicina Familiar** constitui o principal gargalo do sistema, apresentando elevados tempos de espera, forte sobrecarga médica e múltiplos períodos críticos.  
Apesar de o sistema respeitar, na maioria dos casos, as prioridades clínicas, verifica-se que doentes de menor prioridade são fortemente penalizados em contextos de elevada procura.  
A simulação demonstra ainda a necessidade de uma melhor redistribuição dos recursos médicos entre especialidades, de forma a reduzir congestionamentos e melhorar a eficiência global do atendimento.

## Análise dos Gráficos da Simulação

Após a execução e carregamento da simulação, foi possível aceder ao menu de **Gráficos**, que disponibiliza várias representações visuais importantes para compreender o comportamento do sistema, a procura pelas especialidades e o cumprimento das prioridades.

---

### 1. Tempo Médio de Espera por Especialidade

O gráfico de barras mostra os tempos médios de espera por especialidade (em minutos):

- Ortopedia: 2,1  
- Cardiologia: 14,5  
- Pneumologia: 46,2  
- Medicina Familiar: 113,6  
- Pediatria: 0  

![Tempo médio de espera por especialidade](Imagens_suport_md/graf1.png)

**Comentário:** A Medicina Familiar apresenta um tempo de espera muito superior às restantes especialidades, confirmando os resultados das estatísticas e indicando um ponto crítico de congestionamento.

---

### 2. Distribuição do Tempo de Permanência

Distribuição do tempo total dos doentes na clínica, em intervalos de 2 horas:

- 0-2h: 97 pacientes  
- 2-4h: 7 pacientes  
- 4-6h: 5 pacientes  
- 6-8h: 3 pacientes  

![Distribuição do tempo de permanência](Imagens_suport_md/graf2.png)

**Comentário:** A grande maioria dos doentes permaneceu menos de 2 horas, mas existem casos extremos (até 8h), refletindo situações de espera prolongada, especialmente em Medicina Familiar.

---

### 3. Número de Doentes por Especialidade

Número total de doentes atendidos por especialidade:

- Cardiologia: 23  
- Ortopedia: 27  
- Pneumologia: 27  
- Medicina Familiar: 33  
- Pediatria: 2  

![Número de doentes por especialidade](Imagens_suport_md/graf3.png)

**Comentário:** A Medicina Familiar registou maior procura, o que contribui para os tempos de espera elevados observados.

---

### 4. Atendimento Imediato vs Em Espera

Percentagem de doentes atendidos de imediato vs após espera:

- Imediato: 33%  
- Após espera: 67%  

![Atendimento imediato vs em espera](Imagens_suport_md/graf4.png)

**Comentário:** Apenas um terço dos doentes foi atendido de imediato, evidenciando congestionamento e sobrecarga em algumas especialidades.

---

### 5. Atendimento Imediato por Especialidade

Percentagem de doentes atendidos de imediato (versus em espera) por especialidade:

| Especialidade      |Imediato (%) | Em espera (%) |
|--------------------|-------------|---------------|
| Cardiologia        | 47          | 52            |
| Ortopedia          | 74          | 25            |
| Pneumologia        | 3           | 96            |
| Medicina Familiar  | 9           | 90            |
| Pediatria          | 100         | 0             |

![Atendimento imediato por especialidade](Imagens_suport_md/graf5.png)

**Comentário:** Observa-se grande desigualdade na eficiência do atendimento imediato. Pediatria e Ortopedia conseguem atender rapidamente, enquanto Pneumologia e Medicina Familiar apresentam filas persistentes.

---

### 6. Afluência

Gráfico de barras mostrando o número de chegadas em intervalos de 10 minutos. Pico de afluência: 6 chegadas entre 90 e 100 minutos.

![Afluência ao longo do tempo](Imagens_suport_md/graf6.png)

**Comentário:** Os picos de afluência coincidem com períodos de maior pressão, afetando especialmente as especialidades já sobrecarregadas.

---

### 7. Pulseiras por Especialidade

Distribuição de prioridades por especialidade (número de doentes por cor de pulseira):

- Cardiologia: 6 Vermelhas, 7 Amarelas, 10 Verdes  
- Pneumologia: 7 Vermelhas, 9 Amarelas, 11 Verdes  
- Ortopedia: 11 Vermelhas, 10 Amarelas, 6 Verdes  
- Medicina Familiar: 12 Vermelhas, 10 Amarelas, 11 Verdes  
- Pediatria: 2 Amarelas  

![Pulseiras por especialidade (Cardiologia)](Imagens_suport_md/graf7_1.png)
![Pulseiras por especialidade (Pneumologia)](Imagens_suport_md/graf7_2.png)
![Pulseiras por especialidade (Ortopedia)](Imagens_suport_md/graf7_3.png)
![Pulseiras por especialidade (Medicina Familiar)](Imagens_suport_md/graf7_4.png)
![Pulseiras por especialidade (Pediatria)](Imagens_suport_md/graf7_5.png)

**Comentário:** A distribuição mostra que a maioria das especialidades tem doentes de diferentes prioridades, mas os doentes verdes são frequentemente mais penalizados nos tempos de espera.

---

### 8. Tempo Médio de Espera por Pulseira

- Vermelha: 18 min  
- Amarela: 18 min  
- Verde: 105 min  

![Tempo médio de espera por pulseira](Imagens_suport_md/graf8.png)

**Comentário:** O sistema respeita a prioridade para doentes críticos, mas os de menor prioridade enfrentam tempos de espera elevados.

---

### 9. Distribuição por Sexo

- Masculino: 31  
- Feminino: 40  
- Outro: 41  

![Distribuição por sexo](Imagens_suport_md/graf9.png)

**Comentário:** Foram considerados apenas os doentes presentes no ficheiro JSON disponibilizado pelo professor. Este gráfico permite uma análise demográfica parcial.

---

### 10. Distribuição Etária dos Doentes

- 0-2 anos: 0  
- 2-13 anos: 2  
- 13-18 anos: 0  
- 18-25 anos: 6  
- 25-40 anos: 21  
- 40-65 anos: 35  
- 65-80 anos: 22  
- 80+ anos: 26  

![Distribuição etária](Imagens_suport_md/graf10.png)

**Comentário:** A maioria dos doentes situa-se entre os 25 e os 80 anos, refletindo um padrão de procura típico de clínicas gerais.

---

### 11. Evolução das Filas de Espera por Especialidade

Gráfico com linhas de diferentes cores representando cada especialidade. Observações principais:

- Pediatria: sem filas de espera  
- Cardiologia e Pneumologia: filas persistentes durante quase toda a simulação, com evolução relativamente constante  
- Ortopedia: filas presentes até cerca de 330 minutos, depois desaparecem  
- Medicina Familiar: filas presentes durante toda a simulação, com evolução oscilante e aumento significativo a partir de 200 minutos  

![Evolução das filas de espera por especialidade](Imagens_suport_md/graf11.png)

**Comentário:** Este gráfico evidencia claramente que Medicina Familiar foi a especialidade mais crítica, com filas constantes e aumento acentuado ao longo da simulação, refletindo sobrecarga significativa.

---

### Análise Global dos Gráficos

A análise visual confirma os resultados estatísticos e evidencia pontos críticos do sistema:

1. **Medicina Familiar** apresenta maior tempo de espera, filas persistentes e sobrecarga médica, sendo o principal gargalo.  
2. **Prioridades** (pulseiras) são respeitadas, sendo que doentes verdes enfrentam tempos de espera elevados.  
3. **Picos de afluência** coincidem com os períodos de maior pressão, afetando sobretudo especialidades já congestionadas.  
4. **Eficiência de atendimento imediato** varia significativamente entre especialidades, indicando necessidade de melhor alocação de recursos.  
5. Os gráficos de evolução das filas permitem identificar períodos críticos e orientar estratégias para reduzir congestionamento futuro.

## Visualização Dinâmica

A funcionalidade de **Visualização** constitui um extra muito importante da aplicação, permitindo analisar uma simulação de forma dinâmica e em tempo acelerado. Esta ferramenta possibilita observar a **evolução das filas de espera** ao longo do tempo, identificando como os doentes são atendidos e verificando se a prioridade das pulseiras é respeitada.

Ao carregar em **Visualização**, abre-se uma janela que permite escolher a especialidade a analisar.

![Janela de seleção de especialidade](Imagens_suport_md/janela_vis_esp.png)

Por exemplo, selecionando a especialidade **Medicina Familiar**, é possível observar quadrados de diferentes cores (verde, amarelo e vermelho) a aparecer e desaparecer, representando os doentes em tempo real.

- **Exemplo 1 – 249,63 min:**  
  - 2 vermelhos, 2 amarelos, 5 verdes  
  ![Visualização dinâmica aos 249,63 min](Imagens_suport_md/temp_1_vis.png)  

- **Exemplo 2 – 355,91 min:**  
  - 1 amarelo, 8 verdes  
  ![Visualização dinâmica aos 355,91 min](Imagens_suport_md/temp_2_vis.png) 

**Comentário:** Entre os dois momentos, verifica-se que os doentes vermelhos foram atendidos, os amarelos começaram a ser atendidos e os doentes verdes acumularam, aumentando a fila de espera devido à menor prioridade.

---

## Conclusão

Esta simulação permite compreender de forma prática o **funcionamento real de uma clínica ou hospital**, evidenciando pontos críticos, tempos de espera e a eficácia do atendimento, assim como a influência das prioridades na gestão dos utentes. A análise conjunta de **estatísticas, gráficos e visualização dinâmica** oferece uma visão completa e intuitiva do sistema, permitindo avaliar decisões e planeamento de recursos.


### Autores:  
Catarina Pereira Costa (A111924)  
Hugo Pescadinha Lomba (A110406)  
Leonor Ferreira Rodrigues (A111548)