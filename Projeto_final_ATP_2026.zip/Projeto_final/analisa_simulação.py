import json


def carrega_simulacao(nome_ficheiro):
   # Carrega a simulação e devolve:
    #parametros (dicionário)
    #doentes_atendidos (lista)
    #total_doentes (int)
    with open(nome_ficheiro, "r", encoding="utf-8") as f:
        simulacao = json.load(f)
    
    return (simulacao["parametros"], simulacao["doentes_atendidos"], simulacao["total_doentes"], simulacao["medicos"], simulacao["total_medicos"],simulacao["ocupacao_consultorios"],simulacao["histórico_filas"], simulacao["chegadas"],simulacao["filas_espera"])

if __name__ == "__main__":
    nome_ficheiro = input("Qual ficheiro de simulação deseja carregar? ")
    parametros, doentes_atendidos, total_doentes,medicos,total_medicos, ocupacao_consultorios, histórico_filas, chegadas, filas_espera= carrega_simulacao(nome_ficheiro)
    print(f"Simulação carregada com {total_doentes} doentes.")



