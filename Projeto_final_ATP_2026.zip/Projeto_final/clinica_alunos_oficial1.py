
import random
import numpy as np
import json
import constantes as cte
import Doentes as d
import médicos as med
import lista_espera as le
import estatisticas as est
import grafico as graf

# Parâmetros da aplicação
# ---
NUM_MEDICOS =random.randint(len(cte.ESPECIALIDADES),8)
TAXA_CHEGADA = 15 / 60
TEMPO_MEDIO_CONSULTA = 15
TEMPO_SIMULACAO = 8 * 60
DISTRIBUICAO_TEMPO_CONSULTA = "exponential"


#round

CHEGADA = "chegada"
SAIDA = "saída"

# --- Modelo para o evento
# Evento = (tempo: Float, tipo: String, doente: dicionário)
# --- Funções de manipulação
def e_tempo(e):
    return e[0]

def e_tipo(e):
    return e[1]

def e_doente(e):
    return e[2]
# ---
# --- Modelo para a Queue de Eventos
# queueEventos = [Evento]
# --- Funções de manipulação
def procuraPosQueue(q, t):
    i = 0
    while i < len(q) and t > q[i][0]:    #Recebe uma lista de eventos e um tempo de um novo evento e vai procurar na lista de eventos enquanto que nao termina a lista e enquanto que t>que o tempo do respetivo evento.
        i = i + 1                        #retorna a posição onde o evento terá o tempo ordenado e poderá ser inserido
    return i                             #Só criei esta função para dar suporte à função enqueue

def enqueue(q, e):
    pos = procuraPosQueue(q, e[0])      #Recebe a lista de eventos e insere um dado evento na posição procurada pela função acima
    return q[:pos] + [e] + q[pos:]      #A lista é cortada até à posição, insere-se o evento e acrescenta-se a restante lista

def dequeue(q):
    e = q[0]                            #Pega no primeiro evento da lista e retira-o porque é o que surgiu mais cedo por isso tem de ser sempre o primeiro a ser tratado
    q = q[1:]                   #[(5, "chegada", "A"), (10, "chegada", "B"), (12, "saída", B)]-----> [(10, "chegada", "B"), (12, "saída", B)]
    return e, q

# --- Modelo para o médico
# Médico = [id: String, ocupado: Boolean, doente_corrente: dicionario, total_tempo_ocupado: Float, inicio_ultima_consulta: Float]
# --- Funções de manipulação
def m_id(e):        #Aceder ao nome do médico
    return e[0]

def m_ocupado(e):   #Ver se o medico está ou não ocupado- True-ocupado; False-Livre
    return e[1]

def mOcupa(m):        #Troca o estado de ocupação do médico
    m[1] = not m[1]
    return m

def m_doente_corrente(e):  #Devolve o paciente a ser atendido
    return e[2]

def mDoenteCorrente(m, d): #Define que paciente está a ser atendido, mas retorna o medico
    m[2] = d
    return m

def m_total_tempo_ocupado(e):  #Devolve o tempo total de ocupação
    return e[3]

def mTempoOcupado(m, t):  #define o tempo total de ocupação
    m[3] = t
    return m

def m_inicio_ultima_consulta(e):  #Tempo a que começou a consulta atual
    return e[4]

def mInicioConsulta(m, t):   #Define o tempo de inicio da ultima consulta
    m[4] = t
    return m 


# ---

# --- Utilização das distribuições para gerar chegadas e durações das consultas
# ---
def gera_intervalo_tempo_chegada(lmbda):
    return np.random.exponential(1 / lmbda)

def gera_tempo_consulta(TEMPO_MEDIO_CONSULTA, DISTRIBUICAO_TEMPO_CONSULTA):
    if DISTRIBUICAO_TEMPO_CONSULTA == "exponential":
        return np.random.exponential(TEMPO_MEDIO_CONSULTA)
    elif DISTRIBUICAO_TEMPO_CONSULTA == "normal":
        return max(0, np.random.normal(TEMPO_MEDIO_CONSULTA, 5))
    elif DISTRIBUICAO_TEMPO_CONSULTA == "uniform":
        return np.random.uniform(TEMPO_MEDIO_CONSULTA * 0.5, TEMPO_MEDIO_CONSULTA * 1.5)


#Quando um doente chega: gera-se o tempo até à próxima chegada; agenda-se um novo evento de chegada no futuro

#Quando um doente começa consulta: gera-se a duração da consulta; agenda-se um evento de saída para esse doente

#Estas funções não criam eventos, só dizem quantos minutos depois eles devem acontecer.
#-------------------------------------------------------------------------------------------------------------------

# --- Funções auxiliares
# -----------------------------------------
# --- Procura o primeiro médico livre
# ---
def procuraMedico(lista,esp):#Esta função procura o primeiro médico livre e se não encontrar nenhum devolve NONE 
    res = None
    i = 0
    encontrado = False
    while not encontrado and i < len(lista):
        if not lista[i][1] and lista[i][-1]==esp:
            
            res = lista[i]
            encontrado = True
        i = i + 1
    return res


def t(x):
    return round(float(x), 2)
# ---------------------------------------------------------------------------------------

def simula(parametros):
    parametros_usados = parametros.copy()
    TEMPO_SIMULACAO = parametros_usados["TEMPO_SIMULACAO"]
    NUM_MEDICOS = parametros_usados["NUM_MEDICOS"]
    TAXA_CHEGADA = parametros_usados["TAXA_CHEGADA"]
    TEMPO_MEDIO_CONSULTA = parametros_usados["TEMPO_MEDIO_CONSULTA"]
    DISTRIBUICAO_TEMPO_CONSULTA = parametros_usados["DISTRIBUICAO_TEMPO_CONSULTA"]

    # Se NUM_MEDICOS for None, escolhe aleatório e atualiza o dicionário
    if NUM_MEDICOS is None:
        NUM_MEDICOS = random.randint(len(cte.ESPECIALIDADES), 8)
        parametros_usados["NUM_MEDICOS"] = NUM_MEDICOS

    tempo_consulta = t(gera_tempo_consulta(TEMPO_MEDIO_CONSULTA, DISTRIBUICAO_TEMPO_CONSULTA))
    historico_ocupacao = []
    tempo_atual = t(0)
    contadorDoentes = 1
    historico_filas = []
    queueEventos = [] # Lista de eventos que vão acontecer, ordenada por tempo de ocorrência do evento
    filas_espera = le.cria_listas_espera() # Fila de espera - doentes à espera de médico disponível
    # --- Geração da lista de médicos
    medicos=med.cria_medicos(NUM_MEDICOS)#chamar a nossa funçao
    # --- Geração das chegadas de doentes
    chegadas = {} # dicionário de suporte para a geração das consultas
    tempo_atual =t(tempo_atual + gera_intervalo_tempo_chegada(TAXA_CHEGADA))
    while tempo_atual < TEMPO_SIMULACAO:
        doente=d.cria_doente(contadorDoentes) #O primeiro doente fica d1
        contadorDoentes += 1 #o proximo já ficara d2 e vai aumentando ao longo do ciclo
        chegadas[doente["id"]] = tempo_atual
        queueEventos = enqueue(queueEventos, (tempo_atual, CHEGADA, doente))
        tempo_atual = t(tempo_atual + gera_intervalo_tempo_chegada(TAXA_CHEGADA))
    # ---
    # ---
    # --- Tratamento dos eventos
    doentes_atendidos_info = []

    while queueEventos != []:
        evento, queueEventos = dequeue(queueEventos)
        print(e_tipo(evento), evento)
        tempo_atual = e_tempo(evento)
        #------------------------ocupação consultórios/Médicos----------------
        ocupados = 0
        for m in medicos:
            if m_ocupado(m):
                ocupados += 1

        historico_ocupacao.append({
            "tempo": tempo_atual,
            "ocupados": ocupados,
            "livres": len(medicos) - ocupados
        })
        #----------------------------------------------------------------
        if e_tipo(evento) == CHEGADA:
            medico_livre = procuraMedico(medicos, evento[2]["especialidade"])
            #print(medico_livre)
            if medico_livre:    #isto funciona porque uma lista nao vazia é considerada True
                medico_livre = mOcupa(medico_livre) # o médico ficou ocupado
                medico_livre = mInicioConsulta(medico_livre,tempo_atual)
                tempo_consulta = gera_tempo_consulta(TEMPO_MEDIO_CONSULTA, DISTRIBUICAO_TEMPO_CONSULTA)
                medico_livre = mDoenteCorrente(medico_livre, e_doente(evento)) # médico fica a atender o doente que acabou de chegar
                #print(medico_livre)
                queueEventos = enqueue(queueEventos,(t(tempo_atual + tempo_consulta), SAIDA, e_doente(evento)))
            else:
                le.acrescentar_doente_fe(filas_espera, evento[2], tempo_atual)

                historico_filas.append((tempo_atual, evento[2]["especialidade"], le.tamanho_le(filas_espera , evento[2]["especialidade"]),evento[2]["pulseira"], evento[1]))
                print(f"Fila de Espera {evento[2]['especialidade']} ({le.tamanho_le(filas_espera, evento[2]["especialidade"])}): ", filas_espera[evento[2]["especialidade"]])
        elif evento[1] == SAIDA:
            # Vamos libertar o médico e despachar o doente
            i = 0
            encontrado = False
            while i < len(medicos) and not encontrado: # vou procurar o médico que está a atender o doente cuja consulta terminou
                if m_doente_corrente(medicos[i]) == e_doente(evento): # se encontrei o médico que está a atender o doente deste evento
                    medico = medicos[i]
                    #Tempos------------------------------------------------
                    
                    tempo_chegada = chegadas[evento[2]["id"]]
                    tempo_inicio = m_inicio_ultima_consulta(medico)
                    tempo_saida = tempo_atual

                    tempo_espera = est.tempo_espera_doente(tempo_chegada, tempo_inicio)
                    tempo_permanencia = est.tempo_permanencia_doente(tempo_chegada, tempo_saida)

                    doentes_atendidos_info.append({
                    "doente": evento[2]["nome"],
                    "id":evento[2]["id"],
                    "sexo":evento[2]["sexo"],
                    "idade":evento[2]["idade"],
                    "especialidade": evento[2]["especialidade"],
                    "pulseira": evento[2]["pulseira"],
                    "tempo_chegada": t(chegadas[evento[2]["id"]]),
                    "tempo_inicio_consulta": t(m_inicio_ultima_consulta(medico)),
                    "tempo_saida": t(tempo_atual),
                    "tempo_espera": t(tempo_espera),
                    "tempo_permanencia": t(tempo_permanencia),
                    "ficou_em_espera": tempo_espera > 0
                    })
                
                    #----------------------------------------------------------
                    medicos[i] = mOcupa(medicos[i]) # o médico ficou livre
                    medicos[i] = mDoenteCorrente(medicos[i], None)  # não está a atender nenhum doente
                    medicos[i] = mTempoOcupado(medicos[i], t(m_total_tempo_ocupado(medicos[i]) + tempo_atual - m_inicio_ultima_consulta(medicos[i]))) # incremento o tempo da consulta que terminou
                    encontrado = True
                i = i + 1
            
            medico = medicos[i-1]


            esp = medico[-1]  # última posição da lista do médico = especialidade
            if le.ha_doentes(filas_espera, esp):
                prox_doente, tchegada = le.retirar_doente_fe(filas_espera, esp)

                historico_filas.append((tempo_atual, esp, le.tamanho_le(filas_espera, esp), prox_doente["pulseira"], SAIDA))
                medico = mOcupa(medico)
                medico = mInicioConsulta(medico, tempo_atual)
                medico = mDoenteCorrente(medico, prox_doente)
                #print("--------------------------------------------------------------")
                #print(medico)
                #print("--------------------------------------------------------------")

                tempo_consulta = gera_tempo_consulta(TEMPO_MEDIO_CONSULTA, DISTRIBUICAO_TEMPO_CONSULTA)
                queueEventos = enqueue(queueEventos, (tempo_atual + tempo_consulta, SAIDA, prox_doente))
    print("-----------------------------------------------------------------------------------")
    print(f"Doentes atendidos: {len(doentes_atendidos_info)}")
    print(doentes_atendidos_info)
    print("-----------------------------------------------------------------------------------")
    return doentes_atendidos_info, chegadas, historico_filas, medicos, filas_espera, historico_ocupacao,parametros_usados



def guarda_simulacao(doentes_atendidos_info, chegadas, historico_filas, medicos, filas_espera, historico_ocupacao,parametros, nome_ficheiro):
    simulacao = {
        "parametros": parametros,
        "doentes_atendidos": doentes_atendidos_info,
        "total_doentes": len(doentes_atendidos_info),
        "medicos": medicos,
        "total_medicos": len(medicos),
        "ocupacao_consultorios": historico_ocupacao,
        "histórico_filas": historico_filas,
        "chegadas": chegadas,
        "filas_espera": filas_espera
    }
    
    #print(simulacao)
    # Escrever no ficheiro
    f = open(nome_ficheiro, "w", encoding="utf-8")
    json.dump(simulacao, f, indent=4, ensure_ascii=False) #vai criar caso nao exista e escrever um novo apagando o anterior caso já exista
    #simulação-escreve o dicionário   f- o ficheiro está aberto indent=4- organiza o ficheiro (bonito e legível)   ensure_ascii- mantém caracteres como ç à ã
    f.close()
    print("Simulação guardada com sucesso!")



if __name__ == "__main__":
    parametros = {
        "TEMPO_SIMULACAO": 8*60,
        "NUM_MEDICOS": None,
        "TAXA_CHEGADA": 15/60,
        "TEMPO_MEDIO_CONSULTA": 15,
        "DISTRIBUICAO_TEMPO_CONSULTA": "exponential"
    }
    # Executa a simulação normalmente
    doentes_atendidos_info, chegadas, historico_filas, medicos, filas_espera, historico_ocupacao,parametros_usados = simula(parametros)

    # Se quiser guardar, apenas roda esta parte
    # Senão, simplesmente ignora
    guardar = input("Deseja guardar esta simulação? (s/n): ").lower()
    if guardar == "s":
        nome_ficheiro = input("Nome do ficheiro para guardar: ")
        guarda_simulacao(doentes_atendidos_info, chegadas, historico_filas, medicos, filas_espera, historico_ocupacao,parametros_usados, nome_ficheiro)
#-------------------------------------------------------------------------------------------------------------------

