#Estatisticas dos doentes



def tempo_espera_doente(tempo_chegada, tempo_inicio_consulta):
    return tempo_inicio_consulta-tempo_chegada
#Tempo que o doente esperou até ser atendido


def tempo_permanencia_doente(tempo_chegada, tempo_saida):
    return tempo_saida-tempo_chegada
#Tempo que o doente esteve na clinica hospitalar



def maior_tempo_espera(doentes_atendidos_info):
    maior = doentes_atendidos_info[0]["tempo_espera"]
    doentes_max = [doentes_atendidos_info[0]]

    for doente in doentes_atendidos_info[1:]:
        if doente["tempo_espera"] > maior:
            maior = doente["tempo_espera"]
            doentes_max = [doente]
        elif doente["tempo_espera"] == maior:
            doentes_max.append(doente)
        nomes = [d["doente"] for d in doentes_max]
        especialidades = [d["especialidade"] for d in doentes_max]
        id=[d["id"] for d in doentes_max]
    return (nomes,id,especialidades, maior)
#f"{nomes}com {id} na {especialidades} apresenta o maior tempo de espera de {maior}"






def maior_tempo_permanencia(doentes_atendidos_info):
    maior = doentes_atendidos_info[0]["tempo_permanencia"]
    doentes_max = [doentes_atendidos_info[0]]

    for doente in doentes_atendidos_info[1:]:
        if doente["tempo_permanencia"] > maior:
            maior = doente["tempo_permanencia"]
            doentes_max = [doente]
        elif doente["tempo_permanencia"] == maior:
            doentes_max.append(doente)
        nome=[]
        esp=[]
        id=[]
        for d in doentes_max:
            nome.append(d["doente"])
            esp.append(d["especialidade"])
            id.append(d["id"])
    return (nome,id,esp,maior) #f"{nome}com {id} na {esp} apresenta o maior tempo de permanência de {maior}"

def num_pessoas_suspeitas(doentes_atendidos_info):
    tempo_suspeito=120
    num_suspeitos=0
    for doente in doentes_atendidos_info:
        if doente["tempo_espera"]>=tempo_suspeito:
            num_suspeitos+=1
    return f" Do total de doentes {len(doentes_atendidos_info)} há {num_suspeitos} doentes sob vigilância"

#Considerando que um tempo de permanencia excessivo é um tempo superior a 5 horas 300 min)
def analisa_doente(doentes_atendidos_info, id, TEMPO_SIMULACAO):
    d_result = None
    conclusoes = "Doente não encontrado"
    tempo_permanencia_invulgar=300
    res=[]
    for d in doentes_atendidos_info:
        for idd in id:
            if d["id"] == idd:
                d_result = d
                conclusoes_list = []

                if d["tempo_permanencia"]>tempo_permanencia_invulgar and d["tempo_permanencia"] > TEMPO_SIMULACAO:
                    conclusoes_list.append("Permanência superior ao tempo de funcionamento da clínica")
                
                elif d["tempo_permanencia"]>tempo_permanencia_invulgar and d["tempo_permanencia"]< TEMPO_SIMULACAO:
                    conclusoes_list.append(f"Permanência superior a {tempo_permanencia_invulgar//60} horas na clínica hospitalar")
                
                if d.get("ficou_em_espera", False):
                    conclusoes_list.append("Esteve em lista de espera, ou seja, não foi atendido de imediato")

                if d.get("pulseira") == "Verde":
                    conclusoes_list.append("O utente tem pulseira verde, que indica menor prioridade")

                if d.get("tempo_inicio_consulta", 0) > TEMPO_SIMULACAO:
                    conclusoes_list.append("A consulta começou após o fecho da clínica")

                conclusoes = conclusoes_list
                res.append((d_result,conclusoes))
    if res==[]:
        res.append(conclusoes)
    
    return res


def tempos_inicio_consulta(doentes_atendidos_info):
    tempos_inicio=[]
    for d in doentes_atendidos_info:
        tempos_inicio.append((d["doente"], d["tempo_inicio_consulta"]))
    return tempos_inicio

        
def pediatria(doentes_atendidos_info):
    doentes_pediatria=0
    for d in doentes_atendidos_info:
        if d["especialidade"]=="Pediatria":
            doentes_pediatria+=1
    return doentes_pediatria



def especialidades_sob_pressao(
    doentes_atendidos_info,
    medicos,
    tempo_simulacao,
    limite_espera,
    limite_ocupacao
):

    espera_por_esp = {}

    # Agregar tempos de espera por especialidade
    for d in doentes_atendidos_info:
        esp = d["especialidade"].strip().lower()
        espera_por_esp.setdefault(esp, []).append(d["tempo_espera"])

    tempo_medio_espera = {
        esp: sum(valores) / len(valores)
        for esp, valores in espera_por_esp.items()
        if valores
    }

    ocupaçao_por_esp = {}
    num_medicos_por_esp = {}

    # Agregar ocupação dos médicos por especialidade
    for m in medicos:
        esp = m[-1].strip().lower()
        tempo_ocupado = m[3]

        ocupaçao_por_esp[esp] = ocupaçao_por_esp.get(esp, 0) + tempo_ocupado
        num_medicos_por_esp[esp] = num_medicos_por_esp.get(esp, 0) + 1

    taxa_ocupaçao = {
        esp: ocupaçao_por_esp[esp] / (tempo_simulacao * num_medicos_por_esp[esp])
        for esp in num_medicos_por_esp
    }

    sob_pressao = {}

    # Critério de pressão (mantém a ideia, agora com OR)
    for esp in tempo_medio_espera:
        espera = tempo_medio_espera[esp]
        ocupacao = taxa_ocupaçao.get(esp, 0)  # pode ser > 1.0

        if espera >= limite_espera and ocupacao >= limite_ocupacao:
            sob_pressao[esp.capitalize()] = {
                "tempo_medio_espera": round(espera, 2),
                "taxa_ocupacao": round(ocupacao * 100, 2)
            }

    if not sob_pressao:
        return "Não há especialidades sob pressão"

    return sob_pressao




def ocupaçao_medico_perc(medicos, tempo_simulacao):
    texto=[]
    ocupaçao = {}
    for m in medicos:
        id_medico = m[0]
        tempo_ocupado = m[3]
        esp = m[-1]

        percentagem = (tempo_ocupado / tempo_simulacao) * 100

        ocupaçao[id_medico] = {
            "especialidade": esp,
            "ocupação": f"{round(percentagem, 2)}%"
        }

        texto.append(f"O médico {id_medico} da especialidade {ocupaçao[id_medico]["especialidade"]} teve {ocupaçao[id_medico]["ocupação"]} de ocupação")
    return texto
    
#-----------------------------------------------------------------------------------------------------


def tempo_medio_por_pulseira(doentes_atendidos_info):
    tempos = {
        "Vermelha": [],
        "Amarela": [],
        "Verde": []
    }

    for d in doentes_atendidos_info:
        tempos[d["pulseira"]].append(d["tempo_espera"])

    medias = {}
    for cor in tempos:
        if tempos[cor]:
            medias[cor] = round(sum(tempos[cor]) / len(tempos[cor]),2)
        else:
            medias[cor] = 0

    return medias

def gradiente_prioridade(doentes_atendidos_info):
    medias = tempo_medio_por_pulseira(doentes_atendidos_info)

    diff_amarela_vermelha = medias["Amarela"] - medias["Vermelha"]
    diff_verde_amarela = medias["Verde"] - medias["Amarela"]

    conclusoes = []

    # Comparação Vermelha vs Amarela
    if diff_amarela_vermelha > 0:
        conclusoes.append(
            f"Doentes com pulseira amarela esperaram em média mais {diff_amarela_vermelha:.2f} minutos do que os de pulseira vermelha."
        )
    else:
        conclusoes.append(
            f"Doentes com pulseira amarela esperaram em média menos {abs(diff_amarela_vermelha):.2f} minutos do que os de pulseira vermelha."
        )

    # Comparação Amarela vs Verde
    if diff_verde_amarela > 0:
        conclusoes.append(
            f"Doentes com pulseira verde esperaram em média mais {diff_verde_amarela:.2f} minutos do que os de pulseira amarela."
        )
    else:
        conclusoes.append(
            f"Doentes com pulseira verde esperaram em média menos {abs(diff_verde_amarela):.2f} minutos do que os de pulseira amarela."
        )

    return {
        "media_vermelha": round(medias["Vermelha"],2),
        "media_amarela": round(medias["Amarela"],2),
        "media_verde": round(medias["Verde"],2),
        "dif_amarela_vermelha": diff_amarela_vermelha,
        "dif_verde_amarela": diff_verde_amarela,
        "conclusoes": conclusoes
    }

def percentagem_inversao_prioridade(doentes_atendidos_info):
    pares = 0
    inversoes = 0

    prioridade = {
        "Vermelha": 0,
        "Amarela": 1,
        "Verde": 2
    }

    for i in range(len(doentes_atendidos_info)):
        for j in range(len(doentes_atendidos_info)):
            d1 = doentes_atendidos_info[i]
            d2 = doentes_atendidos_info[j]

            if prioridade[d1["pulseira"]] < prioridade[d2["pulseira"]]:
                pares += 1
                if d1["tempo_espera"] > d2["tempo_espera"]:
                    inversoes += 1

    if pares == 0:
        return 0
 
    return f"Em {((inversoes / pares) * 100):.2f}% das comparações analisadas, doentes com menor prioridade apresentaram tempos de espera inferiores, o que se explica por fatores como chegadas espaçadas e indisponibilidade momentânea dos médicos."

#Se a percentagem der um numero diferente de zero nao significa que a prioridade nao foi respeitada, mas por exemplo na especialidade de Cardiologia se surgiram em pico muitos doentes com pulseira vermelha, e noutra chegaram espaçadamente utentes com pulseira verde ou amarela eles provavelmente tambem foram atendidos mais rapido(Por exemplo os medicos podiam estar mais ocupados para os de pulseira vermelha e nao havia medicos para atender e livres nos das outras pulseiras)



def deteta_periodos_criticos(doentes_atendidos_info, tempo_simulacao, limite_espera, intervalo):
    periodos_criticos = []
    cores = ["Vermelha", "Amarela", "Verde"]

    # obter especialidades existentes
    especialidades = []
    for d in doentes_atendidos_info:
        if d["especialidade"] not in especialidades:
            especialidades.append(d["especialidade"])

    t = 0
    while t < tempo_simulacao:
        for esp in especialidades:
            for cor in cores:
                doentes_intervalo = []

                for d in doentes_atendidos_info:
                    if (
                        d["pulseira"] == cor
                        and d["especialidade"] == esp
                        and t <= d["tempo_chegada"] < t + intervalo
                    ):
                        doentes_intervalo.append(d["tempo_espera"])

                if doentes_intervalo:
                    media = sum(doentes_intervalo) / len(doentes_intervalo)
                    if media > limite_espera:
                        periodos_criticos.append({
                            "especialidade": esp,
                            "intervalo": (t, t + intervalo),
                            "pulseira": cor,
                            "media_espera": round(media, 2)
                        })

        t += intervalo  # avanço correto do tempo

    # só no fim é que decidimos se houve ou não períodos críticos
    if not periodos_criticos:
        return f"Não foram detetados períodos críticos em nenhum intervalo de {intervalo} minutos"

    return periodos_criticos

#USAR UM LIMITE DE ESPERA DE 90 E UM INTERVALO DE 60

#Pode ser necessário alterar no clinica na parte do return e na parte do if __name__==main





