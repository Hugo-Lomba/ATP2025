import matplotlib.pyplot as plt
import numpy as np
import constantes as cte
from matplotlib.ticker import MaxNLocator 


#Também podia começar com tempos=defaultdict(list)
def grafico_tempo_medio_espera_por_especialidade(doentes_atendidos_info):
    plt.close('all')
    tempos = {}
    for d in doentes_atendidos_info:
        especialidade = d["especialidade"]
        tempo_espera = d["tempo_espera"]

        if especialidade not in tempos:
            tempos[especialidade] = []

        tempos[especialidade].append(tempo_espera)
# Até aqui eu estou a criar um dicionário que a cada especialidade faz corresponder uma lista de tempos de espera
    
    
    especialidades = []
    medias = []
    for esp, lista_tempos in tempos.items():
        especialidades.append(esp)
        medias.append(sum(lista_tempos) / len(lista_tempos))
# Com o items eu pego no dicionário e transformo numa lista de tuplos [(esp, [tempos espera], (...))
    
    # Criar o gráfico
    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager() #o manager vai mexer na janela do gráfico
    manager.window.geometry("950x600+690+160")

    cores = {
        'Cardiologia': 'blue',
        'Medicina Familiar': 'orange',
        'Ortopedia': 'green',
        'Pneumologia': 'red',
        'Pediatria': 'grey'
    }
    cores_barras = [cores[esp] for esp in especialidades]
    barras = plt.bar(especialidades, medias, color=cores_barras)

    # Colocar valores em cima de cada barra
    for barra in barras:
        altura = barra.get_height() #Dá a altura da barra
        plt.text(
            barra.get_x() + barra.get_width() / 2,  #centra o valor no centro da barra(eixo do x)
            altura,
            f"{altura:.1f}", #Coloca o valor com uma casa decimal
            ha="center", #texto centrado horizontalmente
            va="bottom" #texto começa exatamente em cima da barra
        )

    plt.ylabel("Tempo médio de espera (min)")
    plt.xlabel("Especialidade")
    plt.title("Tempo médio de espera por especialidade")
    plt.show()

#----------------------------------------------------------------------------------------------------------------------
def grafico_distribuicao_tempo_permanencia(doentes_atendidos_info):
    plt.close('all')
    # Contadores para cada intervalo
    intervalos = {
        "0-2h": 0,
        "2-4h": 0,
        "4-6h": 0,
        "6-8h": 0
    }

    for d in doentes_atendidos_info:
        tempo_min = d["tempo_permanencia"]
        tempo_horas = tempo_min / 60  # conversão para horas

        if 0 <= tempo_horas < 2:
            intervalos["0-2h"] += 1
        elif 2 <= tempo_horas < 4:
            intervalos["2-4h"] += 1
        elif 4 <= tempo_horas < 6:
            intervalos["4-6h"] += 1
        elif 6 <= tempo_horas <= 8:
            intervalos["6-8h"] += 1

    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

#"950x600+800+250"
    # Dados para o gráfico
    labels = list(intervalos.keys())
    valores = list(intervalos.values())
    barras = plt.bar(labels, valores, color="blue")
    plt.bar(labels, valores)
    plt.xlabel("Tempo de permanência (horas)")
    plt.ylabel("Número de doentes")
    plt.title("Distribuição do tempo de permanência dos doentes")
    
    #  Mostrar valor em cima de cada barra
    for barra in barras:
        altura = barra.get_height()
        plt.text(
            barra.get_x() + barra.get_width() / 2,
            altura,
            f"{int(altura)}",
            ha="center",
            va="bottom"
        )
    plt.show()


#------------------------------------------------------------------------------------------------------------------------------------------------------------------
def num_doentes_especialidade(doentes_atendidos_info):
    esp = {}
    # Inicializar contadores
    for e in cte.ESPECIALIDADES:
        esp[e] = 0

    # Contar doentes
    for d in doentes_atendidos_info:
        esp[d["especialidade"]] += 1
    return esp

def grafico_doentes_por_especialidade(doentes_atendidos_info):
    plt.close('all')
    dados = num_doentes_especialidade(doentes_atendidos_info)

    especialidades = list(dados.keys())
    valores = list(dados.values())

    
    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    cores=["blue", "red", "green", "orange", "grey"]
    barras = plt.bar(especialidades, valores,color=cores)

    plt.xlabel("Especialidade")
    plt.ylabel("Número de doentes")
    plt.title("Número de doentes atendidos por especialidade")

    #  Valores em cima das barras
    for barra in barras:
        altura = barra.get_height()
        plt.text(
            barra.get_x() + barra.get_width() / 2,
            altura,
            f"{int(altura)}",
            ha="center",
            va="bottom"
        )

    plt.tight_layout()
    plt.show()

#-----------------------------------------------------------------------------------------------------------------------
#Sobre a forma de pie/tarte e no geral ou seja sem ser por especialidade
def atendimento_imediato_vs_em_espera(doentes_atendidos_info):
    plt.close('all')
    doente_imediato = 0
    doente_em_espera = 0

    # Contar os doentes imediatos e em espera
    for d in doentes_atendidos_info:
        if d["tempo_chegada"] == d["tempo_inicio_consulta"]:
            doente_imediato += 1
        else:
            doente_em_espera += 1

    # Criar gráfico de pizza
    plt.figure(figsize = (10,10), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    valores = [doente_imediato, doente_em_espera]
    labels = ["Atendimento imediato", "Atendimento após espera"]

    plt.pie(
        valores,
        labels=labels,
        autopct="%1.1f%%",
        startangle=90,
        colors=["#6bff66", "#ff9999"],
        explode=[0.1, 0],  # destaca a primeira fatia
        shadow=True,
        textprops={'fontsize': 16}
    )

    plt.title("Atendimento imediato vs Atendimento após espera",fontdict={"fontsize":18})
    plt.show()


            
#------------------------------------------------------------------------------------------------------------------
def atendimento_imediato_por_especialidade(doentes_atendidos_info):
    plt.close('all')
    #Criar dicionários para contar atendimentos
    imediatos = {}
    espera = {}

    for d in doentes_atendidos_info:
        esp = d["especialidade"]

        if esp not in imediatos:
            imediatos[esp] = 0
            espera[esp] = 0

        if d["tempo_chegada"] == d["tempo_inicio_consulta"]:
            imediatos[esp] += 1
        else:
            espera[esp] += 1

    # Calcular percentagens por especialidade
    especialidades = list(imediatos.keys())
    perc_imediatos = []
    perc_espera = []

    for esp in especialidades:
        total = imediatos[esp] + espera[esp]
        perc_imediatos.append((imediatos[esp] / total) * 100)
        perc_espera.append((espera[esp] / total) * 100)

    #Criar gráfico de barras agrupadas
    x = np.arange(len(especialidades))  # posições do eixo X
    largura = 0.35  # largura das barras

    
    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    barras1=plt.bar(x - largura/2, perc_imediatos, width=largura, color='green', label='Atendimento imediato')
    barras2=plt.bar(x + largura/2, perc_espera, width=largura, color='red', label='Atendimento com espera')

    #Ajustar eixo X
    plt.xticks(x, especialidades, rotation=45)
    plt.ylabel('Percentagem de doentes (%)')
    plt.xlabel('Especialidade')
    plt.title('Percentagem de doentes atendidos imediatamente vs em espera por especialidade')
    plt.legend()
    for barra in barras1:
        altura = barra.get_height()
        plt.text(
            barra.get_x() + barra.get_width() / 2,
            altura,
            f"{int(altura)}",
            ha="center",
            va="bottom"
        )
    for barra in barras2:
        altura = barra.get_height()
        plt.text(
            barra.get_x() + barra.get_width() / 2,
            altura,
            f"{int(altura)}",
            ha="center",
            va="bottom"
        )

    plt.tight_layout()
    plt.show()


#---------------------------------------------------------------------------------------------------------------------------------------


#chegadas= dicionário com o registo das chegadas


#Afluência 
def graph_afluencia(tempo_simul,chegadas,intervalo):
    plt.close('all')
    t=0 # início do intervalo
    tempos=[] #para guardar os tempos de chegada
    contagem=[] # conta o número de doentes que chegam consoante o tempo
    while t<tempo_simul:
        tempos.append(t)
        conta=0 #inicializa a variável
        for temp_cheg in chegadas.values():# vai buscar os valores de tempo de chegada ao dicionário 
            if t<=temp_cheg<t+ intervalo:# se os valores de tempo de chegada estiver no intervalo [t,t+intervalo[ este último é aberto para o doente que vier no limite não cair me dois intervalos 
                conta+=1 #acrescenta o número de doentes 
        contagem.append(conta)
        t+=intervalo
        
    # determinar onde houve maior afluência de doentes 
    maior=contagem[0]
    t_pico=[]
    for i,d in enumerate(contagem): # unpack do enumerate pois este dá um tuplo(indice,elemento)
        if d>maior:
            maior=d
            t_pico=[tempos[i]]# Reinicia a lista com o novo máximo uma vez que d>maior
        elif d==maior:
            t_pico.append(tempos[i])
    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    plt.bar(tempos,contagem,width=intervalo,edgecolor="skyblue", align="edge")
    plt.scatter([t + intervalo/2 for t in t_pico],[maior] * len(t_pico),color="darkorchid",label="Maior afluência")
    plt.xlabel("Intervalos de tempo (min)")
    plt.ylabel("Nº de chegadas")
    plt.xlim(left=0)
    plt.title("Gráfico de afluência")
    plt.legend()# para funcionar é necessário usar um parâmetro label= em por exemplo plt.scatter(pontos),plt.plot,entre outros
    plt.tight_layout()
    plt.show()


#Pulseiras por especialidade 
def pacientes_especialidade(doentes_atendidos_info):
    d_esp={
        "Cardiologia":[],
        "Pneumologia":[],
        "Ortopedia":[],
        "Medicina Familiar":[], 
        "Pediatria":[]
    }
    for d in doentes_atendidos_info:
        for esp in d_esp:
            if d["especialidade"]==esp:
                d_esp[esp].append(d)
    return d_esp

#d_esp: dicionário de doentes por especialidade


def pulseiras_especialidade(d_esp):
    plt.close('all')
    criterios=["Vermelha","Amarela","Verde"]
    cor=["red","yellow","green"]
    for esp in cte.ESPECIALIDADES:
        ver=0 #dentro do ciclo de modo a serem reiniciadas após cada especialidade
        ama=0
        verd=0
        for d in d_esp[esp]:#para ir buscar cada doente de cada especialidade
            if d["pulseira"]=="Vermelha":
                ver+=1
            elif d["pulseira"]=="Amarela":
                ama+=1
            elif d["pulseira"]=="Verde":
                verd+=1
        valores=[ver,ama,verd]
        
        plt.figure(figsize = (11,6), num = None)

        manager = plt.get_current_fig_manager()
        manager.window.geometry("950x600+690+160")

        plt.title(esp)
        plt.ylabel("Número de doentes")
        plt.xlabel("Cor das pulseiras")
        

        barras = plt.bar(criterios, valores,color=cor)
        plt.ylim(bottom=0,top=max(valores)+1) # a função max dá o maior valor da lista
        plt.gca().yaxis.set_major_locator(MaxNLocator(integer=True))# a escala só usa valores inteiros em y
        for barra in barras:
            altura = barra.get_height()
            x = barra.get_x() + barra.get_width() / 2
            plt.text(x, altura, f"{int(altura)}", ha="center", va="bottom")
        plt.text(0.5,-0.15,"Para avançar para a próxima especialidade clique em fechar",fontdict={"fontsize":12},transform=plt.gca().transAxes,ha="center",fontsize=10,color="red")
        plt.tight_layout()
        plt.show()






#Tempo médio de espera por pulseira 

def paciente_pulseira(doentes):
    d_pulseira={
        "Vermelha":[],
        "Amarela":[],
        "Verde":[]
    }
    for d in doentes:
        if d["pulseira"]=='Vermelha':
            d_pulseira['Vermelha'].append(d)
        elif d["pulseira"]=='Amarela':
            d_pulseira['Amarela'].append(d)
        elif d["pulseira"]=="Verde":
            d_pulseira['Verde'].append(d)
    return d_pulseira

def graph_tempo_pul(d_pulseira):
    plt.close('all')
    criterios=["Vermelha","Amarela","Verde"]
    cor=["red","yellow","green"]
    temp_medio=[]
    for c in criterios:
        tempos=[]#cria uma lista de tempos consoante a cor 
        for d in d_pulseira[c]:
            tempos.append(d["tempo_espera"])# adiciona os tempos de espera
        if tempos!=[]:
            ts=0# variável que acumula os tempos de espera 
            for t in tempos:
                ts+=t
            temp_medio.append(ts/len(tempos))# guarda os tempos médios de espera de cada pulseira 
        else:
            temp_medio.append(0)
    
    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    plt.bar(criterios,temp_medio,color=cor)
    plt.title("Tempo médio de espera por pulseira")
    plt.xlabel("Cor das pulseiras")
    plt.ylabel("Tempo de espera (min)")
    
    barras = plt.bar(criterios,temp_medio,color=cor)
    for barra in barras:
        altura = barra.get_height()
        x = barra.get_x() + barra.get_width() / 2
        plt.text(x, altura, f"{int(altura)}", ha="center", va="bottom")
    plt.tight_layout()
    plt.show()
        


#-----------------------------------------------------------------------------------------------------------------------------------------

def grafico_distribuicao_sexo(doentes):
    plt.close('all')
    contagem = {
        "masculino": 0,
        "feminino": 0,
        "outro": 0
    }

    for d in doentes:
        sexo = d["sexo"].lower()
        if sexo in contagem:
            contagem[sexo] += 1

    labels = list(contagem.keys())
    valores = list(contagem.values())


    cores = ["tab:blue", "tab:pink", "tab:orange"]
    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    barras = plt.bar(labels, valores, color=cores)
    plt.title("Distribuição do Sexo dos Doentes")
    plt.xlabel("Sexo")
    plt.ylabel("Número de Doentes")

    for barra in barras:
        altura = barra.get_height()
        plt.text(barra.get_x() + barra.get_width() / 2,
                 altura,
                 f"{int(altura)}",
                 ha = "center",
                 va = "bottom")

    plt.tight_layout()
    plt.show()




def grafico_distribuicao_idades(doentes):
    plt.close('all')
    faixas = {
        "0-2": 0,
        "2-13": 0,
        "13-18": 0,
        "18-25": 0,
        "25-40": 0,
        "40-65": 0,
        "65-80": 0,
        "80+": 0
    }

    for d in doentes:
        idade = d["idade"]

        if idade < 2:
            faixas["0-2"] += 1
        elif idade < 13:
            faixas["2-13"] += 1
        elif idade < 18:
            faixas["13-18"] += 1
        elif idade < 25:
            faixas["18-25"] += 1
        elif idade < 40:
            faixas["25-40"] += 1
        elif idade < 65:
            faixas["40-65"] += 1
        elif idade < 80:
            faixas["65-80"] += 1
        else:
            faixas["80+"] += 1

    labels = list(faixas.keys())
    valores = list(faixas.values())

    plt.figure(figsize = (11,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    barras = plt.bar(labels, valores, color = "red")
    plt.title("Distribuição Etária dos Doentes")
    plt.xlabel("Faixa Etária")
    plt.ylabel("Número de Doentes")
    plt.xticks(rotation=45)

    for barra in barras:
        altura = barra.get_height()
        plt.text(barra.get_x() + barra.get_width() / 2,
                 altura,
                 f"{int(altura)}",
                 ha = "center",
                 va = "bottom")
        
    plt.tight_layout()
    plt.show()




def grafico_filas(historico_filas, espaço = 10):
    plt.close('all')
    especialidades = list({e[1] for e in historico_filas})
    cores = {
        'Cardiologia': 'blue',
        'Medicina Familiar': 'orange',
        'Ortopedia': 'green',
        'Pneumologia': 'red',
        'Pediatria': 'grey'
    }
    
    plt.figure(figsize = (10,6), num = None)

    manager = plt.get_current_fig_manager()
    manager.window.geometry("950x600+690+160")

    for i, esp in enumerate(especialidades):
        tempos = [e[0] for e in historico_filas if e[1] == esp]
        tamanhos = [e[2] for e in historico_filas if e[1] == esp]

        y = [t + i * espaço for t in tamanhos]

        if tempos:
            plt.plot(tempos, y, marker="o", label=esp, color=cores.get(esp, 'black'))

    yticks = [i * espaço for i in range(len(especialidades))]
    plt.yticks(yticks, especialidades)
    plt.xlabel("Tempo (min)")
    plt.ylabel("Especialidade")
    plt.title("Evolução das filas de espera por especialidade")
    plt.grid(True, axis = "x")
    plt.tight_layout()
    plt.show()


# não está na interface
def grafico_ocupacao_consultorios(historico_ocupacao):
    tempos = []
    ocupados = []
    livres = []

    for h in historico_ocupacao:
        tempos.append(h["tempo"])
        ocupados.append(h["ocupados"])
        livres.append(h["livres"])

    plt.plot(tempos, ocupados, label="Consultórios ocupados")
    plt.plot(tempos, livres, label="Consultórios livres")

    plt.xlabel("Tempo")
    plt.ylabel("Número de consultórios")
    plt.title("Ocupação dos Consultórios ao longo do tempo")
    plt.legend()
    plt.grid(True)
    plt.show()
















