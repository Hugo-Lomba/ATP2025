#lista de espera
import constantes as cte



def cria_listas_espera():
    filas={}
    for esp in cte.ESPECIALIDADES:
        filas[esp]={
            "Vermelha": [],
            "Amarela": [],
            "Verde": []
            
        }
    return filas


def acrescentar_doente_fe(filas,doente,tempo_chegada):
    esp=doente["especialidade"]
    pul=doente["pulseira"]
    filas[esp][pul].append((doente, tempo_chegada))
    return filas

def retirar_doente_fe(filas,especialidade):
    esp=filas[especialidade]
    if esp["Vermelha"]!=[]:
        var=esp["Vermelha"].pop(0)
    elif esp["Amarela"]!=[]:
        var=esp["Amarela"].pop(0)
    elif esp["Verde"]!=[]:
        var=esp["Verde"].pop(0)
    else:
        var="Não se encontra ninguém nesta fila de espera."
    return var
    

def ha_doentes(filas, especialidade):
    fila_esp = filas[especialidade]
    return bool(
        fila_esp["Vermelha"] or
        fila_esp["Amarela"] or
        fila_esp["Verde"] 
    )

def numero_cor_pulseiras(filas, especialidade):
    fila_esp = filas[especialidade]
    return f"""
    Número de pulseiras vermelhas:{len(fila_esp["Vermelha"])},
    Número de pulseiras amarelas:{len(fila_esp["Amarela"])},
    Número de pulseiras verdes:{len(fila_esp["Verde"])}
    """

def tamanho_le(filas, especialidade):
    fila_esp = filas[especialidade]
    return len(fila_esp["Vermelha"]) + len(fila_esp["Amarela"]) + len(fila_esp["Verde"])




