# Médico = [id, ocupado, doente_corrente, total_tempo_ocupado, inicio_ultima_consulta, especialidade]
import constantes as cte
import random

#num_medicos=random.randint(len(cte.ESPECIALIDADES),8)---meter no principal
def cria_medicos(num_medicos):
    medicos = []
    contador = 1

    for esp in cte.ESPECIALIDADES:
        medicos.append([
            f"M{contador}",
            False,
            None,
            0,
            0,
            esp
        ])
        contador+=1

    while contador<=num_medicos:
        medicos.append([
            f"M{contador}",
            False,
            None,
            0,
            0,
            random.choice(cte.ESPECIALIDADES)
        ])
        contador+=1
    return medicos